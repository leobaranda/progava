package files;

public class InvalidGraphFormatException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidGraphFormatException() {
		
	}
}
