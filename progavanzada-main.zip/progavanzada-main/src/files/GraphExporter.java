package files;

import grafos.Graph;

public interface GraphExporter {
	public void export(Graph g, String path);
}
