package coloring;

import grafos.Graph;

public interface OrderMethod {
	public Order generateOrder(Graph g);
}
