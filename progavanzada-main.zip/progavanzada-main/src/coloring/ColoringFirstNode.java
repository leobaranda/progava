package coloring;

import grafos.Graph;

public class ColoringFirstNode implements ColoringMethod{

	@Override
	public Coloring paint(Graph g, Order o) {
		// TODO Auto-generated method stub
		return null;
	}

}
